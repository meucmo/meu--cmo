import express from 'express';
import routes from './routes/index.js';
import errorMiddleware from './middleware/errorMiddleware.js';
import logger from './utils/appLogger.js';

const app = express();

app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

app.use(routes());

app.use((req, res) => {
	res.status(404).json({ error: 'Route not found' });
});

app.use(errorMiddleware);

const port = Number(process.env.PORT) || 3001;
app.listen(port, () => {
	logger.info(`API server listening on port ${port}`);
});
